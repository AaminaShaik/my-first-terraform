def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': 'Hi from aamina first Lambda function from terraform!'
    }
